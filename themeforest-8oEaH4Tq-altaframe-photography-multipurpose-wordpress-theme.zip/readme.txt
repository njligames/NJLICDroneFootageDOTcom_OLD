Thank you for buying Altaframe Theme.

If you have questions for installing and using theme, please visit documentation:
http://altaframe.like-themes.com/documentation/

******************
Theme installation
******************

Standard Theme Installation:
1) Use altaframe.zip file to upload new theme in Appearence -> Themes -> Add new.
2) Install all required plugins (Especialy Unyson and Like-Themes-plugins) and activate them
3) Update permalinks for custom pages in Settings -> Permalink -> Save Changes
4) You can import demo content for quick site setup. 
   Tools -> Demo Content Install. Will install all demo content for the site.

Notice: if you want to use a child-theme, you can also upload the file altaframe-child.zip in addition with the main Altaframe Theme.


*******
Support
*******

You can contact us if you have any questions by support@like-themes.com

http://like-themes.com/
https://themeforest.net/user/like-themes
